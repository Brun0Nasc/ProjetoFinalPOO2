package infra;

public class Sapato extends Componente {

    public Sapato() {
        this.nome = "Sapato";
        this.custo = 15;
    }
    
}

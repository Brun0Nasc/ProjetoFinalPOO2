package interfaces;

public interface IPalmilha {
    String getPalmilha();
}

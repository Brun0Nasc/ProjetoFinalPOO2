package interfaces;

public interface ITecido {
    String getTecido();
}

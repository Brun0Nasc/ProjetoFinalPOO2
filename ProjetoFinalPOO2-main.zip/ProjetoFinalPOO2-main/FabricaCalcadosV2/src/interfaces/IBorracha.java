package interfaces;
public interface IBorracha {
    String getBorracha();
}
